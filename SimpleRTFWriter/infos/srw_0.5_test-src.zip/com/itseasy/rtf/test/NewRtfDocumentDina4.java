package com.itseasy.rtf.test;

import java.io.File;
import java.io.IOException;

import com.itseasy.rtf.RTFDocument;
import com.itseasy.rtf.data.Border;
import com.itseasy.rtf.data.Field;
import com.itseasy.rtf.data.Font;
import com.itseasy.rtf.data.InfoGroup;
import com.itseasy.rtf.data.List;
import com.itseasy.rtf.data.Paragraph;
import com.itseasy.rtf.data.Tabulator;
import com.itseasy.rtf.data.TextPart;


/**
 *  - <Beschreibung>
 *
 * @version 0.1.0 	08.07.2004
 * @author 			IT'S EASY
 */
public class NewRtfDocumentDina4 {

    public static void main(String[] args) {
        // RTF Dokument generieren
        RTFDocument doc = new RTFDocument();
        // Dokumenteninformation hinzuf�gen
        doc.getInfo().setInfoAsString(InfoGroup.INFO_AUTHOR, "IT'S EASY");
        doc.getInfo().setInfoAsString(InfoGroup.INFO_TITLE, "Dies ist ein RTF Generierungstest...");
        // Kopfzeile hinzuf�gen (Zentriert, Schriftgr��e 16, Rahmen am Boden)
        Paragraph header = new Paragraph(0, 18, 16, Font.ARIAL, new TextPart("Simple RTF Writer Testdokument"));
        header.setAlignment(Paragraph.ALIGN_CENTER);
        header.setBorder(new Border(Border.BORDER_BOTTOM, Border.BORDERTHICKNESS_SINGLE));
        doc.addHeader(header);
        // Fu�zeile hinzuf�gen (Dateiname links, Aktuelles Datum und Seitennummer Rechts)
        Paragraph footer = new Paragraph(12, 0, 8, Font.TIMES_NEW_ROMAN);
        footer.addTabulator(new Tabulator(170, Tabulator.TABKIND_RIGHT));	// Tabulator bei 17 cm definieren
        footer.addText(new TextPart("Datei: "));
        footer.addText(Field.FIELD_FILENAME);
        footer.addText(new TextPart(TextPart.SIGN_TAB + "Datum: "));
        footer.addText(Field.FIELD_CURRENT_DATE);
        footer.addText(TextPart.NEWLINE);
        footer.addText(new TextPart(TextPart.SIGN_TAB + "Seite "));
        footer.addText(Field.FIELD_CURRENT_PAGENO);
        footer.addText(new TextPart(" von "));
        footer.addText(Field.FIELD_TOTAL_PAGES);
        footer.setBorder(new Border(Border.BORDER_TOP, Border.BORDERTHICKNESS_SINGLE));
        doc.addFooter(footer);
        // 1. Absatz hinzuf�gen - Schriftm�glichkeiten
        Paragraph absatz = new Paragraph(0, 6);
        absatz.addText(new TextPart("Mit dem Simple RTF Writer (SRW) kann man einfache RTF Dokumente erstellen oder RTF Formulare ausf�llen. Der SRW unterst�zt "));
        absatz.addText(new TextPart(TextPart.FORMAT_ITALIC, "kursiv, "));
        absatz.addText(new TextPart(TextPart.FORMAT_UNDERLINE, "unterstrichen, "));
        absatz.addText(new TextPart(TextPart.FORMAT_BOLD,"fett, "));
        absatz.addText(new TextPart(TextPart.FORMAT_OUTLINE, "outline, "));
        absatz.addText(new TextPart(TextPart.FORMAT_SHADOW, "mit Schatten "));
        absatz.addText(new TextPart("oder "));
        absatz.addText(new TextPart(TextPart.FORMAT_ITALIC + TextPart.FORMAT_UNDERLINE + TextPart.FORMAT_SHADOW 
                + TextPart.FORMAT_BOLD + TextPart.FORMAT_OUTLINE, "alles zusammen."));
        doc.addParagraph(absatz);
        // 2. Absatz hinzuf�gen - Aufz�hlungsliste (Eine Aufz�hlungsliste ist auch ein Absatz!)
        absatz = new Paragraph(0, 0, new TextPart("Daneben k�nnen auch Aufz�hlungslisten erstellt werden, wie diese:"));
        doc.addParagraph(absatz);
        absatz = new List(0, 6);
        absatz.addText(new TextPart("1. Aufz�hlung"));
        absatz.addText(new TextPart("2. Aufz�hlung"));
        absatz.addText(new TextPart("3. Aufz�hlung (Funktioniert auch, wenn ein Aufz�hlungspunkt �ber mehr als eine Zeile geht...)"));
        absatz.addText(new TextPart("4. Aufz�hlung"));
        doc.addParagraph(absatz);
        // 3. Absatz hinzuf�gen - Tabulatoren
        absatz = new Paragraph(0, 6, new TextPart("Nat�rlich unters�tzt der Simple RTF Writer auch Tabulatoren."));
        absatz.addText(TextPart.NEWLINE); 
        // Abs�tze dem 3. Absatz hinzuf�gen - kann auch erst zum Schluss passieren...
        absatz.addTabulator(new Tabulator(10, Tabulator.TABKIND_LEFT));		// 1. Tabulator; 1 cm; Ausrichtung: Links
        absatz.addTabulator(new Tabulator(50, Tabulator.TABKIND_CENTER));	// 2. Tabulator; 5 cm; Ausrichtung: Center
        absatz.addTabulator(new Tabulator(100, Tabulator.TABKIND_DECIMAL));	// 3. Tabulator; 10 cm; Ausrichtung: Dezimal
        absatz.addTabulator(new Tabulator(150, Tabulator.TABKIND_RIGHT));	// 4. Tabulator; 15 cm; Ausrichtung: Rechts
        // Jetzt kommt der Text f�r den 3. Absatz
//        absatz.addText(new TextPart(TextPart.SIGN_TAB + "Links-Tab" + TextPart.SIGN_TAB + "Center-Tab" + TextPart.SIGN_TAB + "Decimal,Tab" + TextPart.SIGN_TAB + "Rechts-Tab"));
        absatz.addText(TextPart.TABULATOR);
        absatz.addText(new TextPart("Links-Tab"));
        absatz.addText(TextPart.TABULATOR);
        absatz.addText(new TextPart("Center-Tab"));
        absatz.addText(TextPart.TABULATOR);
        absatz.addText(new TextPart("Dezimal,Tab"));
        absatz.addText(TextPart.TABULATOR);
        absatz.addText(new TextPart("Rechts-Tab"));
        doc.addParagraph(absatz);
        // 4. Absatz hinzuf�gen - Tabulatoren mit F�llzeichen (Punkte)
        absatz = new Paragraph(0, 0);
        absatz.addTabulator(new Tabulator(10, Tabulator.TABKIND_LEFT));		// 1. Tabulator; 1 cm; Ausrichtung: Links
        absatz.addTabulator(new Tabulator(150, Tabulator.TABKIND_RIGHT, Tabulator.TABLEAD_DOTS));	// 2. Tabulator; 15 cm; Ausrichtung: Rechts
        absatz.addText(new TextPart(TextPart.SIGN_TAB + "Zeilenanfang " + TextPart.SIGN_TAB + " Tab mit Punkten"));
        doc.addParagraph(absatz);
        // 5. Absatz hinzuf�gen - Tabulatoren mit F�llzeichen (Unterstrichen)
        absatz = new Paragraph(0, 0);
        absatz.addTabulator(new Tabulator(10, Tabulator.TABKIND_LEFT));		// 1. Tabulator; 1 cm; Ausrichtung: Links
        absatz.addTabulator(new Tabulator(150, Tabulator.TABKIND_RIGHT, Tabulator.TABLEAD_UNDERLINE));	// 2. Tabulator; 15 cm; Ausrichtung: Rechts
        absatz.addText(new TextPart(TextPart.SIGN_TAB + "Zeilenanfang " + TextPart.SIGN_TAB + " Tab mit Unterstrich"));
        doc.addParagraph(absatz);
        
        // Dokument speichern
        try {
            doc.save(new File("c:/rtftest.rtf"));
            System.out.println("Fertig");
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
}
