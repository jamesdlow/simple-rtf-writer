/*
 * Created on 26.05.2004
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package com.itseasy.rtf.test;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

//import com.itseasy.rtf.RTFDocument;
import com.itseasy.rtf.RTFTemplate;
import com.itseasy.rtf.data.BookmarkIsNotCheckbox;
import com.itseasy.rtf.data.BookmarkNotFoundException;
//import com.itseasy.rtf.data.InfoGroup;
import com.itseasy.rtf.data.MultiTextParts;
//import com.itseasy.rtf.data.Paragraph;
import com.itseasy.rtf.data.TextPart;

/**
 * TestTemplate - ####
 *
 * @version 0.1.0 	22.05.2004
 * @author 			IT'S EASY
 */

public class TestTemplate {

    public static void main(String[] args) {
        try {
            // RTF Template lesen und Textmarken f�llen
            RTFTemplate doc = new RTFTemplate(new File("c:/rtftest_template.rtf"));
            // Text f�r Felder einf�gen
            doc.setBookmarkContent("Nummer", "08/15");
            doc.setBookmarkContent("Wert", "4.060,00");
            doc.setBookmarkContent("MWSt", "560,00");
            doc.setBookmarkContent("Wert_Wort", "-- viertausendsechzig --");
            doc.setBookmarkContent("Von", "Mustermann GmbH, M�nchen");
            doc.setBookmarkContent("Ort_Datum", "M�nchen, " + new SimpleDateFormat("dd.MM.yyyy").format(new Date()));
            // Checkboxen mit Inhalt f�llen
            doc.setBookmarkCheckbox("Bar", true);
            doc.setBookmarkCheckbox("Kreditkarte", false);	// ist eigenltich �berfl�ssig
            // Ausf�hrlicher Inhalt f�r "fuer" definieren
            MultiTextParts mtp = new MultiTextParts();
            mtp.addText(new TextPart("Auftragsarbeit zur Erstellung der Sitzordnung f�r Olympia 2004. Aufragsnummer "));
            mtp.addText(TextPart.NEWLINE);
            mtp.addText(new TextPart("Aufragsnummer: "));
            mtp.addText(new TextPart(TextPart.FORMAT_BOLD, "5533-1092-2004."));
            mtp.addText(TextPart.NEWLINE);
            mtp.addText(new TextPart("Bearbeiter: "));
            mtp.addText(new TextPart(TextPart.FORMAT_UNDERLINE, "Hugo Schmidt"));
            doc.setBookmarkContent("Fuer", mtp);
            // Dokument wieder speichern
            doc.save(new File("c:/rtftest2.rtf"));
            System.out.println("Fertig");
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (BookmarkNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (BookmarkIsNotCheckbox e1) {
            // TODO Auto-generated catch block
            e1.printStackTrace();
        }            // Text f�r "f�r" setzen
    }
}
